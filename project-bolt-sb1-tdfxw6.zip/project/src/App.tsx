import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import Feed from './components/Feed';
import RightSidebar from './components/RightSidebar';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Navbar />
        <div className="pt-16 flex">
          <Sidebar />
          <main className="flex-1 lg:ml-64 xl:mr-80">
            <div className="max-w-7xl mx-auto px-4 py-6">
              <Feed />
            </div>
          </main>
          <RightSidebar />
        </div>
      </div>
    </Router>
  );
}

export default App;
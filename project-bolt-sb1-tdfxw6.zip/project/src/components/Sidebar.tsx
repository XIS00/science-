import React from 'react';
import { Microscope, BookOpen, Users, Calendar, Briefcase } from 'lucide-react';

export default function Sidebar() {
  return (
    <div className="hidden lg:block w-64 fixed left-0 top-16 h-screen border-r border-gray-200 bg-white p-4">
      <div className="space-y-6">
        <ProfileCard />
        <StatsCard />
        <QuickLinks />
      </div>
    </div>
  );
}

function ProfileCard() {
  return (
    <div className="text-center">
      <div className="relative">
        <img
          src="https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=200&h=60&fit=crop"
          alt="Cover"
          className="w-full h-16 object-cover rounded-t-lg"
        />
        <img
          src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=96&h=96&fit=crop"
          alt="Profile"
          className="absolute left-1/2 transform -translate-x-1/2 -bottom-10 w-20 h-20 rounded-full border-4 border-white"
        />
      </div>
      <div className="mt-12">
        <h3 className="font-semibold">Dr. Alex Thompson</h3>
        <p className="text-sm text-gray-500">Neuroscience Researcher</p>
        <p className="text-xs text-gray-400">Stanford University</p>
      </div>
    </div>
  );
}

function StatsCard() {
  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <h4 className="font-medium mb-2">Your Research Impact</h4>
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-500">Citations</span>
          <span className="font-medium">1,234</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-500">Publications</span>
          <span className="font-medium">42</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-500">h-index</span>
          <span className="font-medium">18</span>
        </div>
      </div>
    </div>
  );
}

function QuickLinks() {
  const links = [
    { icon: <Microscope />, text: 'My Research' },
    { icon: <BookOpen />, text: 'Publications' },
    { icon: <Users />, text: 'Collaborators' },
    { icon: <Calendar />, text: 'Conferences' },
    { icon: <Briefcase />, text: 'Grant Opportunities' },
  ];

  return (
    <div>
      <h4 className="font-medium mb-2">Quick Links</h4>
      <div className="space-y-2">
        {links.map((link, index) => (
          <button
            key={index}
            className="flex items-center space-x-3 w-full p-2 rounded-lg hover:bg-gray-100 text-gray-700"
          >
            {React.cloneElement(link.icon as React.ReactElement, { className: 'h-5 w-5' })}
            <span className="text-sm">{link.text}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
import React from 'react';
import { TrendingUp, Users2 } from 'lucide-react';

export default function RightSidebar() {
  return (
    <div className="hidden xl:block w-80 fixed right-0 top-16 h-screen border-l border-gray-200 bg-white p-4">
      <div className="space-y-6">
        <TrendingResearch />
        <SuggestedConnections />
        <UpcomingConferences />
      </div>
    </div>
  );
}

function TrendingResearch() {
  const trends = [
    {
      title: 'CRISPR Gene Editing',
      field: 'Biotechnology',
      mentions: '2.4k discussions',
    },
    {
      title: 'Dark Matter Detection',
      field: 'Physics',
      mentions: '1.8k discussions',
    },
    {
      title: 'AI in Drug Discovery',
      field: 'Pharmaceutical Sciences',
      mentions: '1.5k discussions',
    },
  ];

  return (
    <div>
      <div className="flex items-center space-x-2 mb-4">
        <TrendingUp className="h-5 w-5 text-blue-600" />
        <h3 className="font-semibold">Trending in Research</h3>
      </div>
      <div className="space-y-4">
        {trends.map((trend, index) => (
          <div key={index} className="cursor-pointer hover:bg-gray-50 p-2 rounded">
            <h4 className="font-medium text-sm">{trend.title}</h4>
            <p className="text-xs text-gray-500">{trend.field}</p>
            <p className="text-xs text-gray-400">{trend.mentions}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function SuggestedConnections() {
  const connections = [
    {
      name: 'Dr. Emily Rodriguez',
      title: 'Climate Scientist',
      institution: 'NASA',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=48&h=48&fit=crop',
    },
    {
      name: 'Prof. Michael Chang',
      title: 'Immunologist',
      institution: 'Harvard Medical School',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=48&h=48&fit=crop',
    },
  ];

  return (
    <div>
      <div className="flex items-center space-x-2 mb-4">
        <Users2 className="h-5 w-5 text-blue-600" />
        <h3 className="font-semibold">Suggested Connections</h3>
      </div>
      <div className="space-y-4">
        {connections.map((connection, index) => (
          <div key={index} className="flex items-center space-x-3">
            <img
              src={connection.image}
              alt={connection.name}
              className="w-12 h-12 rounded-full"
            />
            <div className="flex-1">
              <h4 className="font-medium text-sm">{connection.name}</h4>
              <p className="text-xs text-gray-500">{connection.title}</p>
              <p className="text-xs text-gray-400">{connection.institution}</p>
            </div>
            <button className="text-blue-600 text-sm hover:bg-blue-50 px-3 py-1 rounded">
              Connect
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function UpcomingConferences() {
  const conferences = [
    {
      name: 'International Quantum Computing Summit',
      date: 'May 15-17, 2024',
      location: 'Zurich, Switzerland',
    },
    {
      name: 'Global Neuroscience Conference',
      date: 'June 8-10, 2024',
      location: 'Boston, USA',
    },
  ];

  return (
    <div>
      <h3 className="font-semibold mb-4">Upcoming Conferences</h3>
      <div className="space-y-4">
        {conferences.map((conference, index) => (
          <div key={index} className="bg-gray-50 p-3 rounded-lg">
            <h4 className="font-medium text-sm">{conference.name}</h4>
            <p className="text-xs text-gray-500">{conference.date}</p>
            <p className="text-xs text-gray-400">{conference.location}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
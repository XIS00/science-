import React from 'react';
import { ThumbsUp, MessageCircle, Share2, Bookmark } from 'lucide-react';

const posts = [
  {
    id: 1,
    author: {
      name: 'Dr. Sarah Chen',
      title: 'Quantum Physics Researcher at MIT',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop',
    },
    content: 'Excited to share our latest findings on quantum entanglement! Our paper has just been published in Nature Physics. This breakthrough could revolutionize quantum computing.',
    image: 'https://images.unsplash.com/photo-1628595351029-c2bf17511435?w=800&h=400&fit=crop',
    likes: 342,
    comments: 56,
  },
  {
    id: 2,
    author: {
      name: 'Prof. James Wilson',
      title: 'Marine Biology Professor at Scripps Institution',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64&h=64&fit=crop',
    },
    content: 'New research opportunity: Looking for PhD candidates interested in studying deep-sea ecosystems using our advanced submersible technology. DM for details.',
    likes: 189,
    comments: 43,
  },
];

export default function Feed() {
  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-10">
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex space-x-4">
          <img
            src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=48&h=48&fit=crop"
            alt="Your profile"
            className="h-12 w-12 rounded-full"
          />
          <button
            className="flex-grow text-left px-4 py-2 bg-gray-100 rounded-full text-gray-500 hover:bg-gray-200"
          >
            Share your research or findings...
          </button>
        </div>
      </div>

      {posts.map((post) => (
        <div key={post.id} className="bg-white rounded-lg shadow">
          <div className="p-4">
            <div className="flex items-center space-x-3">
              <img
                src={post.author.avatar}
                alt={post.author.name}
                className="h-12 w-12 rounded-full"
              />
              <div>
                <h3 className="font-semibold text-gray-900">{post.author.name}</h3>
                <p className="text-sm text-gray-500">{post.author.title}</p>
              </div>
            </div>
            <p className="mt-4 text-gray-800">{post.content}</p>
            {post.image && (
              <img
                src={post.image}
                alt="Post content"
                className="mt-4 rounded-lg w-full"
              />
            )}
            <div className="mt-4 flex items-center justify-between pt-4 border-t">
              <ActionButton icon={<ThumbsUp />} text={`${post.likes}`} />
              <ActionButton icon={<MessageCircle />} text={`${post.comments}`} />
              <ActionButton icon={<Share2 />} text="Share" />
              <ActionButton icon={<Bookmark />} text="Save" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function ActionButton({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-600">
      {React.cloneElement(icon as React.ReactElement, { className: 'h-5 w-5' })}
      <span className="text-sm">{text}</span>
    </button>
  );
}
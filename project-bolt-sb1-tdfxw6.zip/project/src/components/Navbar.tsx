import React from 'react';
import { Search, BellDot, MessageSquare, Users2, TestTube, Menu } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="fixed top-0 w-full bg-white border-b border-gray-200 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <TestTube className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-800">ScienceConnect</span>
            </Link>
            <div className="hidden md:block ml-6">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search researchers, publications..."
                  className="w-96 pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-6">
            <NavItem icon={<Users2 />} text="Network" />
            <NavItem icon={<MessageSquare />} text="Messages" />
            <NavItem icon={<BellDot />} text="Notifications" />
            <div className="h-8 w-8 rounded-full bg-gray-200 cursor-pointer hover:ring-2 hover:ring-blue-500">
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?fit=crop&w=32&h=32"
                alt="Profile"
                className="h-full w-full rounded-full object-cover"
              />
            </div>
          </div>

          <div className="md:hidden">
            <Menu className="h-6 w-6 text-gray-600" />
          </div>
        </div>
      </div>
    </nav>
  );
}

function NavItem({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div className="flex flex-col items-center cursor-pointer group">
      <div className="p-2 rounded-lg group-hover:bg-gray-100">
        {React.cloneElement(icon as React.ReactElement, { className: 'h-6 w-6 text-gray-600' })}
      </div>
      <span className="text-xs text-gray-600">{text}</span>
    </div>
  );
}